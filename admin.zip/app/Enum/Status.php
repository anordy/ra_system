<?php

namespace App\Enum;

interface Status
{
    static function getConstants(): array;
}