<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WorkflowTaskController extends Controller
{
    //
}
