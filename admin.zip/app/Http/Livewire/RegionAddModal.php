<?php

namespace App\Http\Livewire;

use App\Models\DualControl;
use App\Models\Region;
use App\Traits\DualControlActivityTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use App\Traits\CustomAlert;
use Livewire\Component;

class RegionAddModal extends Component
{

    use CustomAlert, DualControlActivityTrait;

    public $name, $location;


    protected function rules()
    {
        return [
            'name' => 'required|strip_tag|min:2|unique:regions',
            'location' => 'required|strip_tag',
        ];
    }


    public function submit()
    {
        if (!Gate::allows('setting-region-add')) {
            abort(403);
        }

        $this->validate();
        DB::beginTransaction();
        try{
            $region = Region::create([
                'name' => $this->name,
                'location' => $this->location,
                'created_at' =>Carbon::now()
            ]);
            $this->triggerDualControl(get_class($region), $region->id, DualControl::ADD, 'adding new region '.$this->name);
            DB::commit();
            $this->customAlert('success', DualControl::SUCCESS_MESSAGE, ['timer' => 8000]);
            return redirect()->route('settings.region.index');
        }catch(Exception $e){
            DB::rollBack();
            Log::error($e .', '. Auth::user());
            $this->customAlert('error', DualControl::ERROR_MESSAGE, ['timer' => 2000]);
            return redirect()->route('settings.region.index');
        }
    }

    public function render()
    {
        return view('livewire.region-add-modal');
    }
}
